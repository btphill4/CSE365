#include <stdio.h>

int main(int argc, char** argv)
{
   printf("Hello world from C\n");
   int i = 0;
   return 0;
}
