#!/usr/bin/env python

def main():
    print("Hello world from Python")


main()
