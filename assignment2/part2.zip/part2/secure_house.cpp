#include <stdio.h>
#include <sstream>
#include <stdlib.h>
#include <iostream>
#include <vector> 
#include <string.h>      
#include "houseKeys.h"
#include "people.h"

using namespace std;

/** 
Given input:
INSERT KEY adam key
TURN KEY adam
ENTER HOUSE adam
INSERT KEY pat foobar
TURN KEY pat
ENTER HOUSE pat
WHO'S INSIDE?

Given output: 
KEY key INSERTED BY adam
FAILURE adam UNABLE TO TURN KEY key
ACCESS DENIED
KEY foobar INSERTED BY pat
SUCCESS pat TURNS KEY foobar
ACCESS ALLOWED
pat
*/

//key vector
houseKeys *keys = new houseKeys(); 

//get name for insert method
string getName(vector<string> currName)
 {
  string toReturn = currName[2];
  return toReturn;
 }

 //get key Method and add to key vector
string getKey(vector<string> currKey, int x)
 {
  if(x == 0) //Used in conjunction with CHANGE LOCKS command to add new keys
  {
   for(int i=3; i<currKey.size();i++)
    {
     keys->addKey(currKey[i]);
    }
   return "Added";
   }
  else //Used to simply return the name of the key a guest enters
  {
  string toReturn = currKey[3]; 
  return toReturn;
  }
 }

//returns the actions in the command
string getAction(vector<string> currAction)
{
    string toReturn;
    if(currAction[0] == "EXIT")
}

 //read the input and parse it to a string vector
 vector<string> inputToVector(string userInput)
 {
    string temp;
    stringstream sStream(userInput);
    vector<string> inputVector;
    while(sStream >> temp)
    {
        inputVector.push_back(temp);
    }
    return inputVector;
 }

int main(int argc, char* argv[])
{   
    //no keys entered error
    if(argc <= 2)
    {
        cout << "ERROR" << endl;
    }

    //vector variables

    people *home = new people();

    ///People variables
    string owner = argv[1];
    string pKey;
    string fireFighterKey = "FIREFIGHTER_SECRET_KEY";

    //code variables
    string line;
    int result = 0;
    
    //initialize house owner and keys
    //./secure_house selina foobar 
    for(int i = 2; i <= argc; i++)
    {
        keys -> addKey(argv[i]);
    }
    keys->addKey("FIREFIGHTER_SECRET_KEY");


    vector<string> command = inputToVector(line);

    lastCommand = seperateCommand(command);


    /*
    while (getline(cin, line))
    {
        string person;
        string temp;
        string enter = "ENTER";
        string insert = "INSERT";
        string turn = "TURN";
        string whos = "WHO'S";
       
        temp = line;
    
        //prints line        
        //cout << temp << endl;


    
        //INSERT KEY adam key
        if(temp.find(insert) != std::string::npos)
        {
            cout << insert << endl;

            //set person's key to element 3 in temp
            pKey = temp[3];
            //KEY key INSERTED BY adam
            cout << "KEY " << pKey << " INSERTED BY " << temp[2] << endl;
        }

        //TURN KEY adam
        else if(temp.find(turn) != std::string::npos)
        {
            cout << "TURN" << endl;

             for(int i = 0; i <= argc; i++)
            {
                //FAILURE adam UNABLE TO TURN KEY key
                if(pKey != keys[i])
                {
                    //if fails result = 0
                    result = 0; 
                }
                //SUCCESS pat TURNS KEY foobar
                if(pKey == key[i])
                {
                    //if passes result = 1
                    result = 1; 
                    break;
                }
            }
            if(result = 0)
            {
                cout << "FAILURE" << temp[2] << " UNABLE TO TURN KEY " << pKey << endl;
            }
            if(result = 1)
            {
                cout << "SUCCESS " << temp[2] << "TURNS KEY" << pKey << endl;
            }
            
        }


        //ENTER HOUSE adam
        if(temp.find(enter) != std::string::npos)
        {   
            cout << enter << endl;

            //if canEnter() == true
            home->addPeople(person);

            //if canEnter() == false
            cout << "ACCESS DENIED" << endl;
        }


        if(temp.find(whos) != std::string::npos)
        {
            cout << whos << endl;

            home->whosHome();

        }
        
       
       line.clear();
    }
    */
    

    return 0;
}